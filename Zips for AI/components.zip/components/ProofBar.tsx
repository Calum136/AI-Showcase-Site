import { motion } from "framer-motion";

const metrics = [
  "20+ SOPs Consolidated",
  "~70% Lookup Time Reduced",
  "RAG Architecture",
  "Full-Stack TypeScript",
];

export function ProofBar() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      className="hidden md:block sticky top-[72px] z-40 bg-brand-stone/80 backdrop-blur-sm border-b border-surface-line/20"
    >
      <div className="max-w-6xl mx-auto px-4 py-2 flex flex-wrap gap-2 justify-center">
        {metrics.map((metric) => (
          <span
            key={metric}
            className="px-3 py-1 text-xs font-medium bg-surface-paper/60 text-brand-brown border border-surface-line/30 rounded-full"
          >
            {metric}
          </span>
        ))}
      </div>
    </motion.div>
  );
}
